function answer_1() {
  document.getElementById("q1-answer").innerHTML = "<ul><li>D - Document</li><li>O - Object</li><li>M - Model</li></ul>";
}
function answer_2() {
  document.getElementById("q2-answer").innerHTML = "<ul><li>Javascript can change HTML by accessing DOM</li><li>Javascript can add or remove existing elements and attributes</li></ul>";
}
function answer_3()  {
 document.getElementsByClassName("q34-answer")[0].innerHTML = "<ul><li>parent node : A node directly above a node</li><li>Child nodes : Nodes one level directly below</li><li>Sibilng nodes : Nodes at the same level(same parentnode)</li><li>Descendant nodes : A set of nodes any number of levels below another node</li><li>Ancestor nodes : A set of nodes above a node in a tree</li></ul>";
}
function answer_4()  {
 document.getElementsByClassName("q34-answer")[1].innerHTML ="<ul><li>document.getElementById(��ID_NAME��)<ul><li>Returns an element with a given ID_NAME</li><li>Duplicate ID is not allowed in the HTML specification</li></ul></li>  <li>document.getElementsByClassName<ul><li>Get a list of elements based on the class name</li></ul></li>     <li>document.getElementsByName<ul><li>Get a list of elements based on the name</li><li>Name is generally used with input tag</li></ul></li>     <li>document.getElementsByTagName<ul><li>Get a list of elements with the input tag name</li</ul></li>        </ul>"
}

$('a').click(function (event) {
 output = 'Answer5';
$(this).text(output);
})
$('div.item').click(function (event) {
 output = 'Question6';
$(this).text(output).attr('style' , 'font-size:3em');
})

$('span.item').click(function (event) {
 output = 'Question6';
$(this).text(output).attr('style' , 'font-size:3em');
})
$('div.demo').dblclick(function (event) {
 output = 'Question7';
$(this).text(output).attr('style' , 'color:blue');
})

$('div.demo').dblclick(function (event) {
 output = 'Question7';
$(this).text(output).attr('style' , 'color:blue');
})


