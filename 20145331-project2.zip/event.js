   var now = new Date();
   var then = new Date('august 2 2016');
   var gap = now.getTime() - then.getTime();
   gap = Math.floor(gap / (1000 * 60 * 60 * 24)) * -1;
   document.write('<div id="dday">(�ҽ�ź����)D-<span style="font-size:33px;">' + gap + '</span></div>');


function bigger(x) {
  x.style.height = "400px";
  x.style.width = "350px";
}

function normal(x) {
  x.style.height = "150px";
  x.style.width = "130px";
}

