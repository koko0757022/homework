$("#flip").click(function() {
  $("#panel").slideToggle(3000);
});
